using System.Windows;

namespace ScreenColorPicker
{
    public partial class App : Application
    {
    }
}
