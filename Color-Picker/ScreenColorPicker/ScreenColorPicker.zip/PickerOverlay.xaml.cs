using System;
using System.Drawing;
using System.Windows;
using System.Windows.Input;

namespace ScreenColorPicker
{
    public partial class PickerOverlay : Window
    {
        public event Action<Color> ColorPicked;

        public PickerOverlay()
        {
            InitializeComponent();

            WindowStartupLocation = WindowStartupLocation.Manual;

            // Cover the entire virtual desktop (all monitors)
            Left = SystemParameters.VirtualScreenLeft;
            Top = SystemParameters.VirtualScreenTop;
            Width = SystemParameters.VirtualScreenWidth;
            Height = SystemParameters.VirtualScreenHeight;

            Cursor = Cursors.Cross;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Make sure we receive keyboard events (for Esc)
            Keyboard.Focus(this);
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(this);
            var screenPoint = PointToScreen(pos);

            var screenPointInt = new System.Drawing.Point(
                (int)screenPoint.X,
                (int)screenPoint.Y);

            var color = GetColorAtScreenPoint(screenPointInt);

            ColorPicked?.Invoke(color);

            Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                Close();
            }
        }

        private static Color GetColorAtScreenPoint(System.Drawing.Point location)
        {
            using (var bmp = new Bitmap(1, 1, System.Drawing.Imaging.PixelFormat.Format32bppArgb))
            {
                using (var g = Graphics.FromImage(bmp))
                {
                    g.CopyFromScreen(location, System.Drawing.Point.Empty, new System.Drawing.Size(1, 1));
                }

                return bmp.GetPixel(0, 0);
            }
        }
    }
}
