﻿using System.Windows;

namespace ColorPickerDemo;

/// <summary>
///     Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
}