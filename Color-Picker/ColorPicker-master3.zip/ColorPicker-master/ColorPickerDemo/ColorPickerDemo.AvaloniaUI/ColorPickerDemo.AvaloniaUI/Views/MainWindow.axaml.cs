using Avalonia.Controls;

namespace ColorPickerDemo.AvaloniaUI.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}