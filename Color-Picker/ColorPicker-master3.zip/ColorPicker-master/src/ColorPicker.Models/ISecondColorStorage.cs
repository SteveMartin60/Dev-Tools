﻿namespace ColorPicker.Models
{
    public interface ISecondColorStorage
    {
        ColorState SecondColorState { get; set; }
    }
}