# About

Common logic for WPF and AvaloniaUI [color picker](https://github.com/PixiEditor/ColorPicker) controls. Originally developed for
[PixiEditor](https://github.com/PixiEditor/PixiEditor).
