﻿namespace ColorPicker.Models
{
    public enum HexRepresentationType
    {
        RGBA,
        ARGB
    }
}