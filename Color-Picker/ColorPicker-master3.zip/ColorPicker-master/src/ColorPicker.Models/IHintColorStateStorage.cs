﻿namespace ColorPicker.Models
{
    public interface IHintColorStateStorage
    {
        ColorState HintColorState { get; set; }
    }
}