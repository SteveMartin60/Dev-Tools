# Color Picker for Windows.Forms
A dialog class similar to the Windows.Forms ColorPicker that allows editing of a basic color field.
<img width="894" height="497" alt="SS" src="https://github.com/user-attachments/assets/a98ec1f2-2704-4d09-94d8-1467ad593835" />
