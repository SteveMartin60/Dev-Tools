﻿namespace ColorPicker
{
    public class OverlayFormControler
    {
        private MainControler _mainControler;

        public OverlayFormControler(MainControler mainControler)
        {
            _mainControler = mainControler;
        }
    }
}