
using System;
using System.Diagnostics;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
namespace WebView2Browser
{
    public partial class MainWindow : Window
    {
        private async Task NavigateWithRetry(string url, int timeoutInSeconds = 60, int maxRetries = 3)
        {
            var retryCount = 0;
            while (retryCount < maxRetries)
            {
                try
                {
                    await NavigateWithTimeout(url, timeoutInSeconds);
                    return;  // Success
                }
                catch (TimeoutException)
                {
                    retryCount++;
                    if (retryCount == maxRetries)
                        throw;  // Rethrow if max retries reached
                }
            }
        }

        private async Task NavigateWithTimeout(string url, int timeoutInSeconds = 60)
        {
            StatusText.Text = "Loading...";

            var timeoutTask = Task.Delay(TimeSpan.FromSeconds(timeoutInSeconds));
            var navigationTask = _webView.CoreWebView2.NavigateToStringAsync(url);

            var completedTask = await Task.WhenAny(navigationTask, timeoutTask);
            if (completedTask == timeoutTask)
            {
                throw new TimeoutException($"Page load timed out after {timeoutInSeconds} seconds.");
            }

            // Ensure navigation is successful
            if (!_navigationTaskCompletionSource.Task.Result || !_domReadyCompletionSource.Task.Result)
            {
                throw new Exception("Page failed to load completely.");
            }

            StatusText.Text = "Page Loaded Successfully";
        }
    }
}
