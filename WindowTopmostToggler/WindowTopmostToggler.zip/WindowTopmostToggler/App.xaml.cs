using System.Windows;

namespace WindowTopmostToggler
{
    public partial class App : Application
    {
    }
}