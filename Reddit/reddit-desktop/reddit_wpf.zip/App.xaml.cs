using System.Windows;

namespace RedditWpf {
    public partial class App : Application { }
}
